/*
* Luciano Brignone
* ECEN 489 Final Project
* 2DO App
 */

package com.example.finalproject;


public class pushData {
// class to handle the data to be read
    String key;
    String event;
    String date;
    String com;

    public pushData() {
    }

    public pushData(String key , String event, String date, String com) {
        this.event = event;
        this.date = date;
        this.com = com;
        this.key = key;
    }


    public String getKey() {
        return key;
    }

    public void setKey(String Key) {
        this.key = Key;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCom() {
        return com;
    }

    public void setCom(String com) {
        this.com = com;
    }
}

