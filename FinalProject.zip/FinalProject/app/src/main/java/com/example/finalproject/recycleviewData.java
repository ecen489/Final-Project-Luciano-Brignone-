package com.example.finalproject;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.content.Intent;

import java.util.ArrayList;

public class recycleviewData extends RecyclerView.Adapter<recycleviewData.viewData> {

    // This is my adapter class for the recylcerView

    Context context;
    ArrayList<pushData> push;

    public recycleviewData (Context c, ArrayList<pushData> d){
        context = c;
        push = d;
    }

    @Override
    public viewData onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //here is where I inflate the text box
        return new viewData(LayoutInflater.from(context).inflate(R.layout.the_text_box,parent,false));
    }
    @Override

    // if i Click the event make sure Iam able to display the things to take it to the EDIT event class

    public void onBindViewHolder(viewData holder, int position) {
        holder.event.setText(push.get(position).getEvent());
        holder.date.setText(push.get(position).getDate());
        holder.com.setText(push.get(position).getCom());
        //holder.key.setText(push.get(position).getKey());

        final String getName = push.get(position).getEvent();
        final String getComment = push.get(position).getCom();
        final String getDates = push.get(position).getDate();
        final String getKey = push.get(position).getKey();
        //Toast.makeText(context.getApplicationContext(),getKey,Toast.LENGTH_SHORT).show();

        holder.itemView.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent inte = new Intent(context, editEvent.class);
                inte.putExtra("event", getName);
                inte.putExtra("com", getComment);
                inte.putExtra("date", getDates);
                inte.putExtra("key", getKey); //save it to retirve it later
                context.startActivity(inte); // this is where I am pushing it to!!
            }
        });
    }

    @Override
    public int getItemCount() {
        return push.size();
    }

    class viewData extends RecyclerView.ViewHolder{

        TextView event;
        TextView date;
        TextView com;
        //TextView key; dont need this!

        public viewData (@NonNull View itemView){
            super(itemView);
            event = itemView.findViewById(R.id.event);
            date = itemView.findViewById(R.id.date);
            com = itemView.findViewById(R.id.com);
        }

    }

}

