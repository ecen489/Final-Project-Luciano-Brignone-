/*
 * Luciano Brignone
 * ECEN 489 Final Project
 * 2DO App
 */

package com.example.finalproject;
// this Activity is the Home page and handles the recylerView and communicates to the
// database and pulls information (shows it by recylerView)

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class TodoActivity extends AppCompatActivity {

    TextView name;
    TextView done;
    //FirebaseDatabase fbdb;
    DatabaseReference dbrf;
    RecyclerView lst;
    recycleviewData push;
    ArrayList<pushData> view;
    Button nwe;
    Button logoutButton;
    Button geofence;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);

        name = findViewById(R.id.appName);
        done = findViewById(R.id.done);

        lst = findViewById(R.id.everything);
        lst.setLayoutManager(new LinearLayoutManager(this));
        push = new recycleviewData(TodoActivity.this,view );

        view = new ArrayList<pushData>();
        nwe = findViewById(R.id.newevent);
        logoutButton = findViewById(R.id.signOut);
        geofence = findViewById(R.id.geofence);

        nwe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(TodoActivity.this,NewEvent.class);
                startActivity(a);
            }
        });


        //fbdb = FirebaseDatabase.getInstance();
        dbrf = FirebaseDatabase.getInstance().getReference().child("appdata");
        dbrf.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()){

                    pushData r = ds.getValue(pushData.class);
                    view.add(r);
                }
                push = new recycleviewData(TodoActivity.this,view);
                lst.setAdapter(push);
               push.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"No Data",Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void LogoutClick(View view) {
        Toast.makeText(getApplicationContext(),"Logged Out",Toast.LENGTH_SHORT).show();
        startActivity(new Intent(TodoActivity.this, MainActivity.class));
    }

    public void gotolocation(View view) {
        //Toast.makeText(getApplicationContext(),"Logged Out",Toast.LENGTH_SHORT).show();
        startActivity(new Intent(TodoActivity.this, MapsActivity.class));
    }


}

