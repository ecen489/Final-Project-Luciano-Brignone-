package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class NewEvent extends AppCompatActivity {

    TextView event;
    TextView date;
    TextView com;
    EditText addevent;
    EditText adddate;
    EditText addcom;
    Button saveevent;
    Button cancelevent;
    DatabaseReference dbrf;
    int rannum = new Random().nextInt();  // I need to create this inorder to know which event to edit
    String key = Integer.toString(rannum); //convert it to string to save to db


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        event = findViewById(R.id.theEvent);
        date = findViewById(R.id.thedate);
        com = findViewById(R.id.thecom);

        addevent = findViewById(R.id.addEvent);
        adddate = findViewById(R.id.addDate);
        addcom = findViewById(R.id.addCom);

        saveevent = findViewById(R.id.savebttn);
        cancelevent = findViewById(R.id.cancelbtttn);

    }
    // when I add a new event
    public void dbWrite(View view){
        String name = addevent.getText().toString();
        String d = adddate.getText().toString();
        String c = addcom.getText().toString();
        dbrf = FirebaseDatabase.getInstance().getReference().child("appdata").child("event" + key);
        //DatabaseReference ranKey = dbrf.push();

        if(name.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Event name",Toast.LENGTH_SHORT).show();
        } else if(d.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Date",Toast.LENGTH_SHORT).show();
        } else if(c.equals("")) {
            Toast.makeText(getApplicationContext(), "Enter description", Toast.LENGTH_SHORT).show();
        } else{
            dbrf.child("event").setValue(name);
            dbrf.child("date").setValue(d);
            dbrf.child("com").setValue(c);
            dbrf.child("key").setValue(key);
            Toast.makeText(getApplicationContext(),"Data Saved",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(NewEvent.this, TodoActivity.class));
        }


    }
    // takes me back to the home screen
    public void goBack(View view) {
        startActivity(new Intent(NewEvent.this, TodoActivity.class));
    }

    public static boolean isNumeric(String strNum) {
        try {
            int i = Integer.parseInt(strNum);
        } catch (NumberFormatException | NullPointerException nfe) {
            return false;
        }
        return true;
    }

}

