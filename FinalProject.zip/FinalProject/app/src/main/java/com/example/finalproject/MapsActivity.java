/*
 * Luciano Brignone
 * ECEN 489 Final Project
 * 2DO App
 */

package com.example.finalproject;


import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    Double lng = 30.5610;
    Double lat = -96.3628;
    private NotificationCompat.Builder notification_builder; // This will be used to build your notification
    private NotificationManagerCompat notification_manager;// This will be used to display the notification

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        NotificationManager notification_manager = (NotificationManager) this
                .getSystemService(this.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {//This portion of the code handles newer APIs
            String chanel_id = "3000";
            CharSequence name = "Channel Name";
            String description = "Chanel Description";
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel mChannel = new NotificationChannel(chanel_id, name, importance);
            mChannel.setDescription(description);
            mChannel.enableLights(true);
            mChannel.setLightColor(Color.BLUE);
            notification_manager.createNotificationChannel(mChannel);
            notification_builder = new NotificationCompat.Builder(this, chanel_id);
        } else {
            notification_builder = new NotificationCompat.Builder(this); //this code handles older APIs
        }

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) { //This is my starting location
        mMap = googleMap;
        LatLng loc = new LatLng(30.5610, -96.3628);
        setMyMap(loc, "CLL");
    }

    public void setMyMap(LatLng myLatLng, String name) { //setting map to starting location
        mMap.addMarker(new MarkerOptions().position(myLatLng).title(name));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(myLatLng));
    }

    public void click1(View view) {
        LatLng loc = new LatLng(30.5610, -96.3628);
        setMyMap(loc, "Home");
    }

    public void goBack(View view) {
        startActivity(new Intent(MapsActivity.this, TodoActivity.class));
    }

    public void click3(View view) {
        mMap.animateCamera(CameraUpdateFactory.zoomIn());
    }

    public void click4(View view) {
        mMap.animateCamera(CameraUpdateFactory.zoomOut());
    }

    public void clickLoc(View view) { // manage noew location and check if its outisde the "house"

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        else {

            Location loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc != null) {
                double myLat = loc.getLatitude();
                double myLng = loc.getLongitude();
                LatLng locn = new LatLng(myLat, myLng);
                    // check location, if its out of the house, send notification
                if((myLat != lat) && (myLng != lng)){
                    Toast.makeText(getApplicationContext(),"You're out of the house!",Toast.LENGTH_SHORT).show();
                    notification_builder.setSmallIcon(R.drawable.calendar)
                            .setContentTitle("2DOApp: ")
                            .setContentText("Remember to Check the thing that you have to do today!")
                            .setAutoCancel(true);

                    Notification notification = notification_builder.build();
                    NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    manager.notify(1, notification);

                }

                setMyMap(locn, "Me");


            }
        }

    }


}

